package com.jpastore.nexa
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{NexaApp()}}}
@Composable fun NexaApp(){MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF00E676),background=Color(0xFF06110E))){Box(Modifier.fillMaxSize().background(Color(0xFF06110E)).padding(24.dp),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Text("N",color=Color(0xFF00E676),fontSize=72.sp,fontWeight=FontWeight.Black);Text("NEXA",color=Color.White,fontSize=30.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Text("Mobile First",color=Color(0xFF8FA89F));Spacer(Modifier.height(24.dp));Text("Base Android instalada com sucesso.",color=Color.White)}}}}
