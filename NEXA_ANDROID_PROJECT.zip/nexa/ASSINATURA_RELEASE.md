# NEXA — assinatura definitiva

O applicationId permanente é `com.jpastore.nexa`.

No GitHub, crie estes Actions secrets:
- NEXA_KEYSTORE_B64 = conteúdo Base64 do arquivo `nexa-release.jks`
- NEXA_KEYSTORE_PASSWORD = senha guardada no pacote privado da chave
- NEXA_KEY_ALIAS = nexa
- NEXA_KEY_PASSWORD = senha guardada no pacote privado da chave

Depois execute o workflow `NEXA RELEASE APK`.
Todas as versões distribuídas aos usuários devem continuar usando a mesma chave.
Nunca envie o arquivo JKS ou as senhas para o repositório público.
