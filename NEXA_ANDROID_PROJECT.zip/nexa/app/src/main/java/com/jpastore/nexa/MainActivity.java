package com.jpastore.nexa;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.provider.Settings;
import android.speech.*;
import android.speech.tts.*;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity implements RecognitionListener {
 static final int BG=Color.rgb(2,7,5), SURFACE=Color.rgb(7,20,14), SURFACE2=Color.rgb(10,29,19);
 static final int GREEN=Color.rgb(50,238,131), GOLD=Color.rgb(216,180,90), WHITE=Color.rgb(244,250,247), MUTED=Color.rgb(143,164,153), LINE=Color.rgb(31,70,49);
 LinearLayout root,body; SharedPreferences sp; SpeechRecognizer sr; TextToSpeech tts; CoreView core; TextView state,caption;
 ArrayList<String> tasks=new ArrayList<>(),agenda=new ArrayList<>(),history=new ArrayList<>(); String mode="Trabalho"; Random random=new Random(); ArrayList<Voice> ptVoices=new ArrayList<>(); float speechRate=.92f,speechPitch=.97f; String voiceName="";

 public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences("nexa",0);load();initTts();showSplash();}
 int d(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
 GradientDrawable bg(int color,float radius,int stroke){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(d(radius));if(stroke!=0)g.setStroke(d(1),stroke);return g;}
 TextView text(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);v.setFontFeatureSettings("kern");v.setPadding(d(10),d(7),d(10),d(7));return v;}
 TextView chip(String s,boolean active){TextView v=text(s,11,active?BG:WHITE);v.setGravity(Gravity.CENTER);v.setTypeface(android.graphics.Typeface.create("sans-serif-medium",0));v.setBackground(bg(active?GREEN:SURFACE2,19,active?0:LINE));return v;}
 LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(d(18),d(16),d(18),d(16));c.setBackground(bg(SURFACE,26,LINE));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,d(7),0,d(7));c.setLayoutParams(p);return c;}
 void title(LinearLayout c,String over,String main,String sub){TextView o=text(over,10,GREEN);o.setLetterSpacing(.12f);c.addView(o);TextView m=text(main,22,WHITE);m.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);c.addView(m);if(sub!=null)c.addView(text(sub,12,MUTED));}

 void showSplash(){
  final Dialog dlg=new Dialog(this,android.R.style.Theme_Black_NoTitleBar_Fullscreen);
  LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER_HORIZONTAL);x.setPadding(d(28),d(70),d(28),d(34));
  x.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(0,5,3),Color.rgb(4,25,15),Color.rgb(0,6,4)}));
  ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.nexa_logo);x.addView(logo,new LinearLayout.LayoutParams(d(78),d(78)));
  TextView n=text("NEXA",48,WHITE);n.setGravity(17);n.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);n.setLetterSpacing(.14f);x.addView(n,new LinearLayout.LayoutParams(-1,d(70)));
  TextView sub=text("SUA ASSISTENTE INTELIGENTE",10,MUTED);sub.setGravity(17);sub.setLetterSpacing(.14f);x.addView(sub,new LinearLayout.LayoutParams(-1,d(40)));
  CoreView pulse=new CoreView(this);x.addView(pulse,new LinearLayout.LayoutParams(-1,0,1));
  TextView status=text("DESPERTANDO O NÚCLEO",10,GREEN);status.setGravity(17);status.setLetterSpacing(.16f);x.addView(status,new LinearLayout.LayoutParams(-1,d(44)));
  TextView q=text("Disciplina hoje. Liberdade sempre.",13,MUTED);q.setGravity(17);x.addView(q,new LinearLayout.LayoutParams(-1,d(62)));
  dlg.setContentView(x);dlg.show();Handler h=new Handler(Looper.getMainLooper());
  h.postDelayed(()->status.setText("PREPARANDO SUA EXPERIÊNCIA"),650);h.postDelayed(()->status.setText("NEXA PRONTA"),1250);h.postDelayed(()->{dlg.dismiss();home();},1750);
 }

 void shell(String page,String sub,int selected){
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(d(15),d(5),d(15),0);
  root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{BG,Color.rgb(4,18,11),BG}));
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
  ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.nexa_logo);head.addView(logo,new LinearLayout.LayoutParams(d(48),d(48)));
  LinearLayout brand=new LinearLayout(this);brand.setOrientation(LinearLayout.VERTICAL);TextView nn=text("NEXA",20,WHITE);nn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);nn.setLetterSpacing(.12f);brand.addView(nn);TextView on=text("●  ONLINE",9,GREEN);brand.addView(on);head.addView(brand,new LinearLayout.LayoutParams(0,d(60),1));
  TextView pill=chip(mode.toUpperCase(Locale.ROOT),false);head.addView(pill,new LinearLayout.LayoutParams(d(94),d(34)));root.addView(head);
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(0,d(7),0,d(14));
  TextView p=text(page,29,WHITE);p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);body.addView(p);body.addView(text(sub,12,MUTED));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(d(3),d(5),d(3),d(7));nav.setBackground(bg(Color.rgb(5,15,10),24,LINE));
  String[] labels={"⌂\nInício","▣\nAgenda","N\nNEXA","◇\nCentral","✓\nTarefas"};
  for(int i=0;i<5;i++){final int z=i;TextView v=chip(labels[i],i==selected);v.setTextSize(i==2?11:10);v.setOnClickListener(q->{stopListen();if(z==0)home();else if(z==1)agenda();else if(z==2)voice();else if(z==3)central();else tasks();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,d(58),1);lp.setMargins(d(2),0,d(2),0);nav.addView(v,lp);}
  root.addView(nav);setContentView(root);
 }

 void home(){shell("Olá, Júlio!","Vamos tornar hoje um dia produtivo?",0);
  LinearLayout hero=card();title(hero,"NEXA • SEU DIA",greeting(),"Eu cuido da organização para você focar no que importa.");
  hero.addView(text(new SimpleDateFormat("EEEE, dd 'de' MMMM 'de' yyyy",new Locale("pt","BR")).format(new Date()),12,GOLD));
  TextView talk=chip("Conversar com a NEXA   →",true);talk.setOnClickListener(v->voice());LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,d(52));tp.setMargins(0,d(12),0,0);hero.addView(talk,tp);body.addView(hero);
  LinearLayout stats=new LinearLayout(this);String[] nums={""+tasks.size(),""+agenda.size(),"—"};String[] labs={"TAREFAS","COMPROMISSOS","TEMPO AGORA"};
  for(int i=0;i<3;i++){LinearLayout c=card();TextView n=text(nums[i],i==2?20:27,WHITE);n.setGravity(17);n.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);TextView l=text(labs[i],8,GREEN);l.setGravity(17);c.addView(n);c.addView(l);if(i==2){c.setOnClickListener(v->safeOpen("https://www.google.com/search?q=previsao+do+tempo","https://www.google.com/search?q=previsao+do+tempo",""));}LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(d(2),0,d(2),0);stats.addView(c,lp);}body.addView(stats);
  body.addView(text("MODO",10,MUTED));LinearLayout modes=new LinearLayout(this);for(String m:new String[]{"Trabalho","Pessoal","Faculdade"}){TextView v=chip(m,m.equals(mode));v.setOnClickListener(q->{mode=((TextView)q).getText().toString();save();home();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,d(43),1);lp.setMargins(d(2),0,d(2),0);modes.addView(v,lp);}body.addView(modes);
  LinearLayout access=card();title(access,"ACESSO RÁPIDO","O que vamos fazer?","Tudo a poucos toques.");
  String[] acts={"Conversar","Nova tarefa","Novo compromisso","Central","Meu dia","Previsão do tempo"};
  for(int r=0;r<2;r++){LinearLayout row=new LinearLayout(this);for(int i=0;i<3;i++){String z=acts[r*3+i];TextView v=chip(z,false);v.setTextSize(10);v.setOnClickListener(q->{String w=((TextView)q).getText().toString();if(w.equals("Conversar"))voice();else if(w.equals("Nova tarefa"))addTask();else if(w.equals("Novo compromisso"))addAgenda();else if(w.equals("Central"))central();else if(w.equals("Meu dia")){voice();new Handler().postDelayed(()->respond("meu dia"),250);}else safeOpen("https://www.google.com/search?q=previsao+do+tempo","https://www.google.com/search?q=previsao+do+tempo","");});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,d(48),1);lp.setMargins(d(2),d(4),d(2),d(4));row.addView(v,lp);}access.addView(row);}body.addView(access);
  LinearLayout quote=card();title(quote,"FOCO NO PRESENTE","Resultados no futuro.","Organização hoje. Grandes conquistas amanhã.");body.addView(quote);
 }
 String greeting(){int h=Calendar.getInstance().get(Calendar.HOUR_OF_DAY);return h<12?"Bom dia.":h<18?"Boa tarde.":"Boa noite.";}

 void voice(){shell("Conversa","Fale ou escreva. Eu acompanho você.",2);
  LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.RIGHT);TextView cfg=chip("⚙  Voz",false);cfg.setOnClickListener(v->voiceSettings());top.addView(cfg,new LinearLayout.LayoutParams(d(96),d(38)));body.addView(top);
  LinearLayout hero=card();hero.setGravity(Gravity.CENTER_HORIZONTAL);core=new CoreView(this);core.setOnClickListener(v->toggleListen());hero.addView(core,new LinearLayout.LayoutParams(-1,d(310)));
  state=text("PRONTA",10,GREEN);state.setGravity(17);state.setLetterSpacing(.18f);hero.addView(state);caption=text("Toque no núcleo e fale comigo",14,WHITE);caption.setGravity(17);hero.addView(caption);hero.addView(text("O núcleo reage à sua voz, pensa e responde.",11,MUTED));body.addView(hero);
  LinearLayout quick=new LinearLayout(this);for(String z:new String[]{"Meu dia","+ Tarefa","Agenda"}){TextView v=chip(z,false);v.setOnClickListener(q->{String w=((TextView)q).getText().toString();if(w.equals("Meu dia"))respond("meu dia");else if(w.contains("Tarefa"))addTask();else agenda();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,d(42),1);lp.setMargins(d(2),0,d(2),0);quick.addView(v,lp);}body.addView(quick);
  LinearLayout chat=card();title(chat,"CONVERSA RECENTE","NEXA","Seu histórico local.");if(history.isEmpty())chat.addView(text("Comece falando comigo ou digitando abaixo.",12,MUTED));else for(int i=Math.max(0,history.size()-6);i<history.size();i++){TextView b=text(history.get(i),12,WHITE);b.setBackground(bg(SURFACE2,16,0));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,d(3),0,d(3));chat.addView(b,lp);}body.addView(chat);
  LinearLayout comp=new LinearLayout(this);EditText input=new EditText(this);input.setSingleLine();input.setHint("Mensagem para NEXA...");input.setHintTextColor(MUTED);input.setTextColor(WHITE);input.setPadding(d(16),0,d(12),0);input.setBackground(bg(SURFACE2,24,LINE));TextView send=chip("➤",true);
  View.OnClickListener go=v->{String m=input.getText().toString().trim();if(!m.isEmpty()){input.setText("");history.add("Você  •  "+m);save();setState(2,"PENSANDO","Analisando...");new Handler().postDelayed(()->respond(m),250);}};send.setOnClickListener(go);input.setOnEditorActionListener((v,a,e)->{go.onClick(v);return true;});comp.addView(input,new LinearLayout.LayoutParams(0,d(52),1));LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(d(58),d(52));slp.setMargins(d(6),0,0,0);comp.addView(send,slp);body.addView(comp);
  TextView priv=text("Privacidade local  •  dados salvos neste aparelho",10,MUTED);priv.setGravity(17);body.addView(priv);
 }

 void agenda(){shell("Agenda","Hoje, semana e próximos compromissos.",1);
  LinearLayout filters=new LinearLayout(this);for(String z:new String[]{"Dia","Semana","Mês"}){TextView v=chip(z,z.equals("Dia"));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,d(42),1);lp.setMargins(d(2),0,d(2),0);filters.addView(v,lp);}body.addView(filters);
  LinearLayout head=card();title(head,"PLANEJAMENTO",new SimpleDateFormat("EEEE, dd 'de' MMMM",new Locale("pt","BR")).format(new Date()),agenda.isEmpty()?"Nenhum compromisso cadastrado.":agenda.size()+" compromisso(s).");TextView add=chip("+  Novo compromisso",true);add.setOnClickListener(v->addAgenda());head.addView(add,new LinearLayout.LayoutParams(-1,d(48)));body.addView(head);
  if(agenda.isEmpty()){LinearLayout empty=card();TextView ic=text("◫",48,GREEN);ic.setGravity(17);empty.addView(ic);title(empty,"AGENDA LIVRE","Seu dia está aberto.","Adicione compromissos para a NEXA organizar sua rotina.");body.addView(empty);}else for(String z:agenda){LinearLayout c=card();title(c,"COMPROMISSO",z,"Toque e segure para excluir.");c.setOnLongClickListener(v->{agenda.remove(z);save();agenda();return true;});body.addView(c);}
 }
 void tasks(){shell("Tarefas","Prioridades claras. Progresso visível.",4);
  LinearLayout filters=new LinearLayout(this);for(String z:new String[]{"Todas","Hoje","Semana","Concluídas"}){TextView v=chip(z,z.equals("Todas"));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,d(42),1);lp.setMargins(d(2),0,d(2),0);filters.addView(v,lp);}body.addView(filters);
  LinearLayout head=card();title(head,"PROGRESSO",tasks.isEmpty()?"Tudo em ordem":tasks.size()+" tarefa(s) ativa(s)",tasks.isEmpty()?"Crie sua próxima prioridade.":"Mantenha o ritmo.");TextView add=chip("+  Nova tarefa",true);add.setOnClickListener(v->addTask());head.addView(add,new LinearLayout.LayoutParams(-1,d(48)));body.addView(head);
  if(tasks.isEmpty()){LinearLayout empty=card();TextView ic=text("✓",48,GREEN);ic.setGravity(17);empty.addView(ic);title(empty,"SEM PENDÊNCIAS","Sua lista está limpa.","Quando surgir algo importante, registre aqui.");body.addView(empty);}else for(String z:tasks){LinearLayout c=card();title(c,"PENDENTE",z,"Toque e segure para concluir/remover.");c.setOnLongClickListener(v->{tasks.remove(z);save();tasks();return true;});body.addView(c);}
 }

 void central(){shell("Central","Aplicativos e serviços em um só lugar.",3);
  LinearLayout intro=card();title(intro,"NEXA HUB","Seu ecossistema conectado","Se o app estiver instalado, ele abre diretamente. Caso contrário, uso a versão web.");body.addView(intro);
  String[][] a={{"G","Google","https://www.google.com","https://www.google.com",""},{"A","Google Agenda","https://calendar.google.com","https://calendar.google.com",""},{"D","Drive","https://drive.google.com","https://drive.google.com",""},{"W","WhatsApp","whatsapp://send","https://wa.me/","com.whatsapp"},{"I","Instagram","instagram://app","https://www.instagram.com/","com.instagram.android"},{"C","ChatGPT","https://chatgpt.com","https://chatgpt.com",""},{"Y","YouTube","vnd.youtube://","https://www.youtube.com","com.google.android.youtube"},{"M","Gmail","mailto:","https://mail.google.com",""},{"↗","Maps","geo:0,0?q=","https://maps.google.com",""}};
  for(String[] z:a){LinearLayout c=card();LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView ic=chip(z[0],true);r.addView(ic,new LinearLayout.LayoutParams(d(44),d(44)));LinearLayout lab=new LinearLayout(this);lab.setOrientation(LinearLayout.VERTICAL);lab.addView(text(z[1],16,WHITE));lab.addView(text("Abrir serviço",10,MUTED));r.addView(lab,new LinearLayout.LayoutParams(0,-2,1));TextView op=chip("Abrir  →",false);r.addView(op,new LinearLayout.LayoutParams(d(92),d(40)));View.OnClickListener go=v->safeOpen(z[2],z[3],z[4]);c.setOnClickListener(go);op.setOnClickListener(go);c.addView(r);body.addView(c);}
 }
 void safeOpen(String deep,String web,String pkg){try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(deep));if(pkg!=null&&!pkg.isEmpty())i.setPackage(pkg);startActivity(i);}catch(Exception e){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(web)));}catch(Exception x){Toast.makeText(this,"Serviço indisponível.",Toast.LENGTH_SHORT).show();}}}

 void addTask(){EditText e=new EditText(this);e.setHint("Ex.: Revisar relatório");new AlertDialog.Builder(this).setTitle("Nova tarefa").setView(e).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{String x=e.getText().toString().trim();if(!x.isEmpty()){tasks.add(x);save();tasks();}}).show();}
 void addAgenda(){EditText e=new EditText(this);e.setHint("Ex.: Reunião às 14h");new AlertDialog.Builder(this).setTitle("Novo compromisso").setView(e).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{String x=e.getText().toString().trim();if(!x.isEmpty()){agenda.add(x);save();agenda();}}).show();}
 void voiceSettings(){
  LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(d(22),d(8),d(22),0);
  TextView info=text("A NEXA prioriza automaticamente as melhores vozes em português disponíveis no seu Android.",12,MUTED);box.addView(info);
  Spinner voices=new Spinner(this);ArrayList<String> names=new ArrayList<>();int selected=0;
  if(ptVoices.isEmpty())names.add("Voz padrão do Android");else for(int i=0;i<ptVoices.size();i++){names.add(prettyVoice(ptVoices.get(i),i));if(ptVoices.get(i).getName().equals(voiceName))selected=i;}
  ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);voices.setAdapter(ad);voices.setSelection(selected);box.addView(voices,new LinearLayout.LayoutParams(-1,d(52)));
  TextView rl=text("Velocidade  •  "+String.format(Locale.US,"%.2fx",speechRate),12,WHITE);box.addView(rl);
  SeekBar rate=new SeekBar(this);rate.setMax(100);rate.setProgress((int)((speechRate-.65f)/.70f*100));box.addView(rate);
  TextView pl=text("Tom  •  "+String.format(Locale.US,"%.2f",speechPitch),12,WHITE);box.addView(pl);
  SeekBar pitch=new SeekBar(this);pitch.setMax(100);pitch.setProgress((int)((speechPitch-.70f)/.60f*100));box.addView(pitch);
  rate.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean f){speechRate=.65f+(v/100f)*.70f;rl.setText("Velocidade  •  "+String.format(Locale.US,"%.2fx",speechRate));applyVoice();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
  pitch.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int v,boolean f){speechPitch=.70f+(v/100f)*.60f;pl.setText("Tom  •  "+String.format(Locale.US,"%.2f",speechPitch));applyVoice();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
  new AlertDialog.Builder(this).setTitle("Voz da NEXA").setView(box).setNegativeButton("Cancelar",null).setNeutralButton("Ouvir amostra",(d,w)->{applyVoice();speak("Olá, Júlio. Eu sou a NEXA. Vamos organizar o seu dia?");}).setPositiveButton("Salvar",(d,w)->{if(!ptVoices.isEmpty()){Voice v=ptVoices.get(voices.getSelectedItemPosition());tts.setVoice(v);voiceName=v.getName();}sp.edit().putFloat("rate",speechRate).putFloat("pitch",speechPitch).putString("voiceName",voiceName).apply();applyVoice();Toast.makeText(this,"Voz ajustada.",Toast.LENGTH_SHORT).show();}).show();
 }

 void initTts(){tts=new TextToSpeech(this,status->{if(status==TextToSpeech.SUCCESS){tts.setLanguage(new Locale("pt","BR"));speechRate=sp.getFloat("rate",.92f);speechPitch=sp.getFloat("pitch",.97f);voiceName=sp.getString("voiceName","");ptVoices.clear();try{for(Voice v:tts.getVoices()){Locale l=v.getLocale();if(l!=null&&"pt".equals(l.getLanguage()))ptVoices.add(v);}Collections.sort(ptVoices,(a,b)->Integer.compare(scoreVoice(b),scoreVoice(a)));Voice pick=null;for(Voice v:ptVoices)if(v.getName().equals(voiceName)){pick=v;break;}if(pick==null&&!ptVoices.isEmpty())pick=ptVoices.get(0);if(pick!=null){tts.setVoice(pick);voiceName=pick.getName();}}catch(Exception ignored){}applyVoice();}});}
 int scoreVoice(Voice v){int n=0;Locale l=v.getLocale();if(l!=null&&"BR".equalsIgnoreCase(l.getCountry()))n+=100; n+=v.getQuality()*2; n-=v.getLatency(); if(!v.isNetworkConnectionRequired())n+=15;String x=v.getName().toLowerCase(Locale.ROOT);if(x.contains("neural")||x.contains("natural")||x.contains("premium")||x.contains("wavenet"))n+=80;return n;}
 void applyVoice(){if(tts!=null){tts.setSpeechRate(speechRate);tts.setPitch(speechPitch);}}
 String prettyVoice(Voice v,int i){String n=v.getName();String type=v.isNetworkConnectionRequired()?"rede":"dispositivo";return (i==0?"★ ":"")+("BR".equalsIgnoreCase(v.getLocale().getCountry())?"Português Brasil":"Português")+" • "+type+" • "+(i+1);}

 void toggleListen(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},9);return;}if(sr==null){sr=SpeechRecognizer.createSpeechRecognizer(this);sr.setRecognitionListener(this);}Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR");i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);sr.startListening(i);setState(1,"OUVINDO","Pode falar...");}
 void stopListen(){try{if(sr!=null)sr.stopListening();}catch(Exception ignored){}}
 void setState(int m,String a,String b){if(core!=null){core.mode=m;core.invalidate();}if(state!=null)state.setText(a);if(caption!=null)caption.setText(b);}
 void respond(String raw){String m=raw.toLowerCase(new Locale("pt","BR"));String ans;
  if(m.contains("bom dia")||m.contains("boa tarde")||m.contains("boa noite")||m.matches(".*\\b(oi|olá|ola)\\b.*"))ans="Olá, Júlio. Estou aqui. O que vamos organizar?";
  else if(m.contains("meu dia")||m.contains("hoje"))ans="Você tem "+tasks.size()+" tarefa(s) e "+agenda.size()+" compromisso(s) cadastrados.";
  else if(m.contains("quem é você")||m.contains("quem e voce"))ans="Eu sou a NEXA, sua assistente pessoal para rotina, agenda, tarefas e organização.";
  else if(m.contains("obrigad"))ans="Sempre às ordens. Quando precisar, é só me chamar.";
  else if(m.contains("tarefa"))ans="Posso registrar uma tarefa para você. Abra Tarefas ou use o atalho Nova tarefa.";
  else ans=new String[]{"Entendi. Posso ajudar a transformar isso em uma tarefa, compromisso ou próximo passo.","Certo. Estou acompanhando. Quer organizar isso na sua rotina?","Recebido. Posso registrar isso para você ou continuar a conversa."}[random.nextInt(3)];
  history.add("NEXA  •  "+ans);save();setState(3,"RESPONDENDO",ans);speak(ans);
 }
 void speak(String s){if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"nexa");}

 void save(){sp.edit().putString("mode",mode).putString("tasks",join(tasks)).putString("agenda",join(agenda)).putString("history",join(history)).apply();}
 void load(){mode=sp.getString("mode","Trabalho");tasks=split(sp.getString("tasks",""));agenda=split(sp.getString("agenda",""));history=split(sp.getString("history",""));}
 String join(ArrayList<String> a){return android.text.TextUtils.join("\u001f",a);}
 ArrayList<String> split(String s){ArrayList<String>a=new ArrayList<>();if(!s.isEmpty())a.addAll(Arrays.asList(s.split("\u001f",-1)));return a;}

 public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float r){if(core!=null){core.level=Math.max(.15f,Math.min(1f,(r+2)/10f));core.invalidate();}} public void onBufferReceived(byte[] b){}
 public void onEndOfSpeech(){setState(2,"PENSANDO","Processando sua voz...");}
 public void onError(int e){setState(0,"PRONTA","Toque no núcleo para tentar novamente.");}
 public void onResults(Bundle b){ArrayList<String>a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(a!=null&&!a.isEmpty()){history.add("Você  •  "+a.get(0));save();respond(a.get(0));}}
 public void onPartialResults(Bundle b){} public void onEvent(int t,Bundle b){}
 protected void onDestroy(){super.onDestroy();if(sr!=null)sr.destroy();if(tts!=null)tts.shutdown();}

 class CoreView extends View{
  Paint p=new Paint(3);float phase=0,level=.3f;int mode=0;
  CoreView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);post(anim);}
  Runnable anim=new Runnable(){public void run(){phase+=mode==2?.12f:.055f;invalidate();postDelayed(this,24);}};
  protected void onDraw(Canvas c){float x=getWidth()/2f,y=getHeight()/2f,pulse=(float)((Math.sin(phase)+1)/2);int col=mode==2?GOLD:GREEN;
   p.setStyle(Paint.Style.STROKE);
   p.setStrokeCap(Paint.Cap.ROUND);
   RectF arc1=new RectF(x-d(104),y-d(104),x+d(104),y+d(104));p.setStrokeWidth(d(2));p.setColor(Color.argb(150,Color.red(col),Color.green(col),Color.blue(col)));c.drawArc(arc1,(phase*24)%360,72,false,p);c.drawArc(arc1,180+(phase*18)%360,46,false,p);
   RectF arc2=new RectF(x-d(88),y-d(88),x+d(88),y+d(88));p.setStrokeWidth(d(1));p.setColor(GOLD);c.drawArc(arc2,300-(phase*16)%360,34,false,p);
   for(int j=0;j<8;j++){double a=phase*.45+j*Math.PI/4;float pr=d(112)+(float)Math.sin(phase+j)*d(4);p.setStyle(Paint.Style.FILL);p.setColor(Color.argb(80+j*8,Color.red(col),Color.green(col),Color.blue(col)));c.drawCircle(x+(float)Math.cos(a)*pr,y+(float)Math.sin(a)*pr,d(j%3==0?2.2f:1.2f),p);}
   p.setStyle(Paint.Style.STROKE);
   for(int i=6;i>=1;i--){float r=d(56+i*14)+d(8)*pulse*(.4f+level);p.setStrokeWidth(d(i==1?2:1));p.setColor(Color.argb(14+i*10,Color.red(col),Color.green(col),Color.blue(col)));c.drawCircle(x,y,r,p);}
   for(int k=0;k<3;k++){Path path=new Path();p.setStrokeWidth(d(k==1?3:1));p.setColor(Color.argb(k==1?220:65,Color.red(col),Color.green(col),Color.blue(col)));for(int i=0;i<=180;i++){float xx=x-d(92)+d(184)*i/180f;float env=(float)Math.sin(Math.PI*i/180f);float amp=(d(9)+d(18)*level)*env*(k==1?1f:.65f);float yy=y+(float)Math.sin(i*.24+phase*(1.5+k*.18))*amp;if(i==0)path.moveTo(xx,yy);else path.lineTo(xx,yy);}c.drawPath(path,p);}
   p.setStyle(Paint.Style.FILL);p.setShader(new RadialGradient(x-d(18),y-d(22),d(82),new int[]{Color.rgb(60,245,137),Color.rgb(8,83,45),Color.rgb(2,19,11)},new float[]{0,.5f,1},Shader.TileMode.CLAMP));p.setShadowLayer(d(28),0,0,Color.argb(140,Color.red(col),Color.green(col),Color.blue(col)));c.drawCircle(x,y,d(62)+d(5)*pulse,p);p.clearShadowLayer();p.setShader(null);
   p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(d(2));p.setColor(GOLD);c.drawCircle(x,y,d(68)+d(3)*pulse,p);
   p.setStyle(Paint.Style.FILL);p.setColor(WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);p.setTextSize(d(38));String g=mode==1?"•":mode==2?"···":mode==3?"≈":"N";c.drawText(g,x,y+d(13),p);
  }
 }
}